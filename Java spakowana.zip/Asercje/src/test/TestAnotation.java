package test;

import org.junit.*;

public class TestAnotation {
    @BeforeClass
    public static void beforeClass (){
        System.out.println("Przed klasą - BeforeClass");
            }
    @AfterClass
    public static void afterClass (){
        System.out.println("Po Klasie - AfterClass");
    }

    @After
    public void after (){
        System.out.println("Za Testem");
    }

    @Before
    public void before(){
        System.out.println("Przed testem");
    }

    @Test
    public void test (){
        System.out.println("To jest test");
    }
    @Ignore
    public void ignoretest (){
        System.out.println("Ominięcie testu");
    }

}
