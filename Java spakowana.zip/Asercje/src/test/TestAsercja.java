package test;

import org.junit.Test;

import static org.junit.Assert.*;

public class TestAsercja {
    @Test
    public void testAssertions(){
        // dane testowe

        String str1 = new String("Janusz");
        String str2 = new String("Janusz");
        String str3 = null;
        String str4 = "Janusz";
        String str5 = "Janusz";


        int val1 = 5;
        int val2 = 6;

        String[]oczekiwanaArr = {"Jeden", "Dwa", "Trzy"};
        String[]wynikowa = {"Jeden", "Dwa", "Trzy"};

        assertEquals(str1, str1);
        assertTrue(val1<val2);
        assertFalse(val1>val2);
        assertNotNull(str1);
        assertNull(str3);
        assertSame(str4, str5);

        assertNotSame(str1, str3);
        assertArrayEquals(oczekiwanaArr, wynikowa);


    }

}
