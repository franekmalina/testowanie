package com.tom;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import test.TestAsercja;
import org.junit.runner.Result;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Result wynik = JUnitCore.runClasses(TestAsercja.class);

        for(Failure failure:wynik.getFailures()){
            System.out.println(failure.toString());
        }

        System.out.println(wynik.wasSuccessful());



        Result wynik2 = JUnitCore.runClasses(TestAsercja.class);

        for(Failure failure:wynik2.getFailures()){
            System.out.println(failure.toString());
        }

        System.out.println(wynik2.wasSuccessful());
    }
    }
