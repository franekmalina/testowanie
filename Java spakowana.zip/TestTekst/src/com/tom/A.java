package com.tom;

public class A {
    public String concatenate (String jeden, String drugi){
        return jeden+drugi;

    }
}
