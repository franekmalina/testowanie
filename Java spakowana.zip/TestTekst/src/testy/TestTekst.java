package testy;

import com.tom.A;
import org.junit.Assert;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class TestTekst {

    @Test

    public void testConcat(){
        A tt = new A();
        String wynik = tt.concatenate("takie", "tam");
        Assert.assertEquals("takietam",wynik);
        Assert.assertEquals("takietamo",wynik);

    }


}
