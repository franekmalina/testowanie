package test;

import org.junit.Test;
import com.tom.PrzypadekTestowy;
import static org.junit.Assert.assertFalse;

public class test {

    @Test

    public void sprawdzenie() {

        PrzypadekTestowy przypadek1 = new PrzypadekTestowy(4,6,7);
        PrzypadekTestowy przypadek2 = new PrzypadekTestowy(4,4,7);
        PrzypadekTestowy przypadek3 = new PrzypadekTestowy(4,6,0);

        String wynik1 = String.valueOf(przypadek1.policz());
        String wynik2 = String.valueOf(przypadek2.policz());
        String wynik3 = String.valueOf(przypadek3.policz());

        assertFalse("Infinity", Boolean.parseBoolean(wynik1));
        assertFalse("Dzielenie przez 0", Boolean.parseBoolean(wynik2));
        assertFalse("Dzielenie przez 0", Boolean.parseBoolean(wynik3));



    }
}