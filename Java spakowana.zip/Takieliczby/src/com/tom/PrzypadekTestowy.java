package com.tom;

public class PrzypadekTestowy {

    double x;
    double y;
    double k;


    public PrzypadekTestowy(double x, double y, double k) {
        this.x = x;
        this.y = y;
        this.k = k;
    }



    public double policz(){

        if (x == y || k == 0){
            System.out.println("Nie dziel cholero przez Zero");
        }

        return (x+y)*x/(x-y)*k;
    }
}
