package com.tom;

import com.sun.source.tree.BinaryTree;

public class Main {

    public static void main(String[] args) {
	// write your code here

        int a =3;

        if (a % 2 == 0) {
            System.out.println("Liczba parzysta");
             } else {
                 System.out.println("Liczba nieparzysta");
             }

        if (a>10) {
            System.out.println("ale masz dużą liczbę");

        }
        else if(a>0 && a<=10) {
            System.out.println("Liczba w przedziale 0-10");


        }
        else if(a==10) {
            System.out.println("Liczba 0");

        }
        else {
            System.out.println("Liczba mniejsza niż 0");
        }


        switch (a) {
            case 1:
                System.out.println("liczba to 1");
                break;
            case 3:
                System.out.println("liczba to 3");
                break;
            case 10:
                System.out.println("liczba to 10");
                break;
            default:
                System.out.println("Liczba inna niż 1,3,10");
                break;
        }

        int[] liczby = new int[100];
        for(int i=0; i<100; i++){
            liczby[i]=i*3+1;
        }
        for(int x : liczby)
            System.out.println("Elementy Tablicy:" + x);



    }
}
