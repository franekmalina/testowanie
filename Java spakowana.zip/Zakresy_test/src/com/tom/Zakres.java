package com.tom;

public class Zakres {
    private final long dolnaGranica;
    private final long gornaGranica;

    public Zakres(long dolnaGranica, long gornaGranica) {
        this.dolnaGranica = dolnaGranica;
        this.gornaGranica = gornaGranica;
    }

    public boolean czwartoscwzakresie(long liczba){
     return liczba>=dolnaGranica && liczba<=gornaGranica;
    }



}
