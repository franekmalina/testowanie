package com.tom;

import org.junit.Assert;
import org.junit.Test;

public class TestZakresu {

    @Test
    public void powinnobycwzakresie(){
        Zakres zak = new Zakres(10,20);
        Assert.assertTrue(zak.czwartoscwzakresie(12));
        Assert.assertTrue(zak.czwartoscwzakresie(10));
        Assert.assertFalse(zak.czwartoscwzakresie(-14));
        Assert.assertTrue(zak.czwartoscwzakresie(109));

    }

}
