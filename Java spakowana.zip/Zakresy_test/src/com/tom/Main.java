package com.tom;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Zakres z = new Zakres(667, 1099);
        System.out.println(z.czwartoscwzakresie(800));
        System.out.println(z.czwartoscwzakresie(2300));


    }
}
