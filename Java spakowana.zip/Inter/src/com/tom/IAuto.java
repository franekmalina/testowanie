package com.tom;

public interface IAuto {
    double predkosc(double p);
    double policzspalanie(double spal_100, int km);
    double kosztprzejazdu(int km, double cena_1, double spal);

}
