package com.tom;

public class Auto implements IAuto {
    String marka;
    String typ;
    Integer rocznik;
    String silnik;
    Double poj;
    Double spal_100;

    public Auto(String marka, String typ, Integer rocznik, String silnik, Double poj, Double spal_100) {
        this.marka = marka;
        this.typ = typ;
        this.rocznik = rocznik;
        this.silnik = silnik;
        this.poj = poj;
        this.spal_100 = spal_100;
    }

    @Override
    public double predkosc(double p) {
        return p;
    }

    @Override
    public double policzspalanie(double spal_100, int km) {
        return spal_100*km/100;
    }

    @Override
    public double kosztprzejazdu(int km, double cena_1, double spal_100) {
        return spal_100*km/100*cena_1;
    }
}
