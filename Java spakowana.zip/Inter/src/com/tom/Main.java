package com.tom;

public class Main {

    public static void main(String[] args) {
	// write your code here

    Auto car = new Auto("Fort","elegancki", 1987, "LPG+PNG", 40.0, 6.8);
        System.out.println("Predkosc pojazdu: " + car.predkosc(112));
        System.out.println("Spalanie w trasie: " + car.policzspalanie(6.8, 393));
        System.out.println("Koszt przejazdu: "+ car.kosztprzejazdu(393, 4.99, 6.8) + " zł");

    }
}
