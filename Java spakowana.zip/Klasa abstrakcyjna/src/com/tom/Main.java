package com.tom;

public class Main {

    public static void main(String[] args) {
	// write your code here

Prostokat pr = new Prostokat(7,2);
Trojkat tr = new Trojkat(44, 33);

System.out.println("Pole prostokąta wynosi: " + pr.policzpole());
System.out.println("Pole trojkata: " + tr.policzpole());

Trapes trap = new Trapes(3,4,7);
System.out.println("Pole trapesa: " + trap.policzpole());

Kolo kolo = new Kolo(4);
System.out.println("Pole koła: " + kolo.policzpole());



    }
}
