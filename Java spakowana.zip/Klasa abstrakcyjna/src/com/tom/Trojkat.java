package com.tom;

public  class Trojkat extends Figura {

    public Trojkat(double a, double b) {
        super(a, b);
    }

    @Override
    public double policzpole() {
        return a*b/2;
    }
}
