package com.tom;

public class Prostokat extends Figura{

    public Prostokat(double a, double b) {
        super(a, b);
    }

    @Override
    public double policzpole() {
        return a*b;
    }
}
