package com.tom;

public abstract class Figura {
    protected double a,b;

    public Figura(double a) {
        this.a = a;
    }

    public Figura(double a, double b) {
        this.a = a;
        this.b = b;
    }
    public abstract double policzpole ();

}
