package com.tom;

public class Trapes extends Figura {
    double h;

    public Trapes(double a, double b, double h) {
        super(a, b);
        this.h = h;
    }

    @Override
    public double policzpole() {
        return (a+b)*h/2;
    }
}
