package com.tom;

class Punkty{                       // nazwa klasy z duzej litery. I przynajmniej jedna klasa ma miec te sama nazwe co nazwa pliku
    int wspX;
    int wspY;
    void ustawX(int x){         // set zawsze void, a get zawsze int
        wspX=x;
    }
    void ustawY(int y){
        wspY=y;
    }
    int dajX(){
        return wspX;
    }
    int dajY(){
        return wspY;
    }
}

public class Main {

    public static void main(String[] args) {
	// write your code here

    Punkty  pkt = new Punkty();
    Punkty  pkt2 = new Punkty();

    pkt.ustawX(45);
    pkt.ustawX(21);

    pkt2.ustawY(11);
    pkt2.ustawY(33);

    System.out.println("Współrzędne: x1 =" + pkt.dajX() + ", y1=" + pkt.dajY() + ".");
    System.out.println("Współrzędne: x2 =" + pkt2.dajX() + ", y2=" + pkt2.dajY() + ".");


    }
}
