package com.tom;


public class Student extends Jagier {
    String uczelnia;
    String rok;
    String kierunek;
    String numer_indexu;


    public Student(String imie, String nazwisko, String plec, String data_urodzenia, String uczelnia, String rok, String kierunek, String numer_indexu) {
        super(imie, nazwisko, plec, data_urodzenia);
        this.uczelnia = uczelnia;
        this.rok = rok;
        this.kierunek = kierunek;
        this.numer_indexu = numer_indexu;
    }

    @Override
    public String printOsoba() {
        return super.printOsoba() + "\nJest studentem uczelni: " + uczelnia + "\nKierunek: " + kierunek + "\nRok: " + rok + "\nNumer indexu: " + numer_indexu;
    }
}