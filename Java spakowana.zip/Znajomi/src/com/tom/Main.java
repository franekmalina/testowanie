package com.tom;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Jagier os1 = new Jagier("Mik", "Jagier", "Meszczyzna", "1950");
        Jagier os2 = new Jagier("Piotr", "Jagier", "Też menszczyzna", "1970");

        System.out.println("\n\n" +os1.printOsoba());
        System.out.println("\n\n" +os2.printOsoba());

        Student st1 = new Student("łukasz","B", "Meszczyzna", "11.11.1976", "UMCZ",
                "2005", "Cośtamznawstwo", "23268");

        System.out.println("\n\n" +st1.printOsoba());

    }
}
