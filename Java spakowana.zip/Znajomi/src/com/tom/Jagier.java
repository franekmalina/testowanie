package com.tom;

public class Jagier {
    String imie;
    String nazwisko;
    String plec;
    String data_urodzenia;

    public Jagier(String imie, String nazwisko, String plec, String data_urodzenia) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.plec = plec;
        this.data_urodzenia = data_urodzenia;
        System.out.println("Zbudowano obiekt osoba.");
    }

    public String printOsoba(){
    return "Nowa osoba - \nImie: " + imie + "\nNazywisko: " + nazwisko + "\nPłeć: " + plec + "\nData urodzenia: " + data_urodzenia;

    }
}