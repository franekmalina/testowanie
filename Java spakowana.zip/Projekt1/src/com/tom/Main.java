package com.tom;

import java.math.BigInteger;

public class Main {

    public static void main(String[] args) {
	// write your code here
    // public lub private lub protected - z zewnatrz nie ma dostepu do private. Main musi byc publiczna
    // void - nic nie zwraca

        System.out.println("Witaj Dżagerze");
        System.out.println("a" + "A");
        System.out.println('a' + 'A');
        System.out.println(1+2);
        System.out.println(1.0+2.0);
        System.out.println(true);

        int a = 5;
        int b = a;

        System.out.println(a +b);

        double liczba3, liczba4;
        liczba3 = 5.5;
        liczba4 = 4.4;

        System.out.println(liczba3*liczba4);
        System.out.println((liczba3*b)/(liczba4-a));

        double n = 9.0;
        int g =3;
        double root = Math.sqrt(n);
        System.out.println(root);

        double power = Math.pow(n,g); //najpierw podstawa potegi, potem wartosc potegi
        System.out.println(power);

        BigInteger k = new BigInteger("328384632322222"); // Bigintigera nie można użyć bezposrednio, wiec używamy kopii - new
        BigInteger l = new BigInteger("34553");

        BigInteger suma = k.multiply(l);
        System.out.println(suma);

        
    }

}
