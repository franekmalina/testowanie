package testy;

import com.tom.MessageUtil;
import org.junit.Test;

import static junit.framework.TestCase.assertEquals;

public class TestMessage {
    String message = "Bardzo istotna wiadomość!";
    MessageUtil messageUtil = new MessageUtil("Nowe Info" + message);

    @Test
    public void testPrintMessage(){
        assertEquals(message,messageUtil.printMessage());

    }


}
