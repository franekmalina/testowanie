package com.tom;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import testy.TestMessage;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Result wynik = JUnitCore.runClasses(TestMessage.class);
        for (Failure failure:wynik.getFailures()){
            System.out.println(failure.toString());
        }
        System.out.println(wynik.wasSuccessful());
    }
}
