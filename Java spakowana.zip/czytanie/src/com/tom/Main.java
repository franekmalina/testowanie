package com.tom;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Scanner in = new Scanner(System.in);

        System.out.println("Podaj liczbe x");
        int x = in.nextInt();
        System.out.println("Podaj liczbe y");
        double y = in.nextInt();

        int potega = (int)Math.pow(y,x);

        System.out.println("Wartość potęgi (typ int)" + potega);

        double potega_2 = (double)Math.pow(y,x);

        System.out.println("Wartość potęgi (typ double)" + potega_2);

// Tablica generyczna
        int roz = 1500;
        ArrayList<Integer> arrli = new ArrayList<Integer>(roz);

        for(int i=1;i<=roz;i++){
            arrli.add(i+1);

        }
        System.out.println(arrli);



        arrli.remove(5);
        System.out.println(arrli);

        for(int k=0; k<arrli.size(); k++){
            System.out.println(arrli.get(k) + " -- ");

        }



    }
}
