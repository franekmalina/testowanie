package com.tom;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Test<Integer> iObj = new Test<>(14);
        System.out.println(iObj.getObj());

        Test<String> iObj2 = new Test<>("To jest tekst");
        System.out.println(iObj2.getObj());

        Test2<Integer, String> football = new Test2<>(9, "Lewandowski");

        football.print();

    }
}
