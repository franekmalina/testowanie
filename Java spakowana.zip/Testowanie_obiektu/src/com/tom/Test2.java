package com.tom;

public class Test2<T,U> {
    T obiekt;
    U obiekt2;

    public Test2(T obiekt, U obiekt2) {
        this.obiekt = obiekt;
        this.obiekt2 = obiekt2;

    }

    public void print(){
        System.out.println(obiekt);
        System.out.println(obiekt2);
    }

}
